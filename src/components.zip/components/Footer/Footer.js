import React from "react";
import './Footer.css';

function Footer() {
  return (
    <div className="footer"><h2>© 2025 All right reserved by <span>Motion Education</span></h2></div>
  )
}

export default Footer