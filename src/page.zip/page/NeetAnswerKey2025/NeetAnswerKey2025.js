import React from "react";
import neetanswerstyles from "./NeetAnswerKey2025.module.css";
import Section1 from "../../components/NeetAnswerKey2025Section/Section1";



const NeetAnswerKey2025 = () => {
  return (
    <div className="main">
        <Section1 styles={neetanswerstyles}/>
    </div>
  );
};

export default NeetAnswerKey2025;