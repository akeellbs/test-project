import React from "react";
import jeemainansStyles from "./JeeMainAnswerKeyPaper2025.module.css";
import Section1 from "../../components/JeeMainAnswerKeyPaper2025Section/Section1.js";



const JeeMainAnswerKeyPaper2025 = () => {
  return (
    <div className="main">
        <Section1 styles={jeemainansStyles}/>
    </div>
  );
};

export default JeeMainAnswerKeyPaper2025;